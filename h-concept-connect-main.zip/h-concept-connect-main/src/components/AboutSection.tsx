import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Award, Users, Clock } from "lucide-react";

const AboutSection = () => {
  const features = [
    {
      icon: <CheckCircle className="w-6 h-6 text-secondary" />,
      title: "Premium Quality",
      description: "We source only the finest materials and work with skilled craftsmen to ensure exceptional quality in every piece."
    },
    {
      icon: <Award className="w-6 h-6 text-secondary" />,
      title: "Expert Craftsmanship",
      description: "Our experienced team brings years of expertise in furniture design and manufacturing to create lasting pieces."
    },
    {
      icon: <Users className="w-6 h-6 text-secondary" />,
      title: "Customer Focused",
      description: "We prioritize customer satisfaction with personalized service and custom solutions for every need."
    },
    {
      icon: <Clock className="w-6 h-6 text-secondary" />,
      title: "Reliable Service",
      description: "From consultation to delivery and installation, we ensure a smooth and professional experience."
    }
  ];

  return (
    <section id="about" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div className="space-y-8">
            <div>
              <Badge className="mb-4 secondary-gradient text-secondary-foreground">About H Concept Furniture</Badge>
              <h2 className="text-4xl md:text-5xl font-bold mb-6">
                Your Trusted Partner in 
                <span className="secondary-gradient bg-clip-text text-transparent"> Premium Furniture</span>
              </h2>
              <p className="text-lg text-muted-foreground mb-6">
                At H Concept Furniture, we believe that great furniture is more than just functional—it's an expression of your style and a foundation for creating memorable moments. Led by Haji Nadeem, our team is dedicated to bringing you the finest furniture solutions that combine style, comfort, and durability.
              </p>
              <p className="text-lg text-muted-foreground">
                With a passion for design and a commitment to excellence, we've helped countless customers transform their spaces into beautiful, functional environments that reflect their unique personality and needs.
              </p>
            </div>

            {/* Owner Spotlight */}
            <Card className="shadow-card border-l-4 border-l-secondary">
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 rounded-full primary-gradient flex items-center justify-center text-primary-foreground font-bold text-xl mr-4">
                    HN
                  </div>
                  <div>
                    <h3 className="font-bold text-lg">Haji Nadeem</h3>
                    <p className="text-secondary font-medium">Founder & Owner</p>
                  </div>
                </div>
                <p className="text-muted-foreground">
                  "Our mission is simple: to provide exceptional furniture that enhances your lifestyle. Every piece we offer is carefully selected and crafted to meet our high standards of quality and design."
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Features Grid */}
          <div className="grid sm:grid-cols-2 gap-6">
            {features.map((feature, index) => (
              <Card key={index} className="shadow-card hover:shadow-elegant transition-smooth group">
                <CardContent className="p-6">
                  <div className="mb-4 group-hover:scale-110 transition-smooth w-fit">
                    {feature.icon}
                  </div>
                  <h3 className="font-bold text-xl mb-3">{feature.title}</h3>
                  <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Stats Section */}
        <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
          <div className="p-6">
            <div className="text-4xl font-bold primary-gradient bg-clip-text text-transparent mb-2">500+</div>
            <p className="text-muted-foreground">Happy Customers</p>
          </div>
          <div className="p-6">
            <div className="text-4xl font-bold secondary-gradient bg-clip-text text-transparent mb-2">1000+</div>
            <p className="text-muted-foreground">Furniture Pieces Delivered</p>
          </div>
          <div className="p-6">
            <div className="text-4xl font-bold primary-gradient bg-clip-text text-transparent mb-2">5+</div>
            <p className="text-muted-foreground">Years of Excellence</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;