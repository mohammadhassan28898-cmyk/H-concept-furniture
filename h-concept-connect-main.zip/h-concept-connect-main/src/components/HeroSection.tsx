import { Button } from "@/components/ui/button";
import { Phone, MessageCircle } from "lucide-react";

const HeroSection = () => {
  const handleCall = () => {
    window.open('tel:+919326363603', '_self');
  };

  const handleWhatsApp = () => {
    const message = "Hello! I'm interested in H Concept Furniture products. Can you help me?";
    window.open(`https://wa.me/919326363603?text=${encodeURIComponent(message)}`, '_blank');
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center hero-gradient overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.1'%3E%3Ccircle cx='30' cy='30' r='2'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }} />
      </div>
      
      <div className="container mx-auto px-4 text-center relative z-10 fade-in">
        {/* Logo */}
        <div className="mb-8">
          <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-white/10 backdrop-blur-sm logo-shine mb-4">
            <span className="text-4xl font-bold text-white">H</span>
          </div>
          <h1 className="text-5xl md:text-7xl font-bold text-white mb-2">
            H Concept
          </h1>
          <h2 className="text-2xl md:text-3xl text-white/90 font-light">
            Furniture
          </h2>
        </div>

        {/* Tagline */}
        <p className="text-xl md:text-2xl text-white/80 mb-4 max-w-2xl mx-auto">
          Transform Your Space with Premium Quality Furniture
        </p>
        <p className="text-lg text-white/70 mb-8 max-w-xl mx-auto">
          Discover our exquisite collection of modern and classic furniture designed to elevate your home and office spaces.
        </p>

        {/* Owner Info */}
        <div className="mb-8 p-4 bg-white/10 backdrop-blur-sm rounded-xl max-w-md mx-auto">
          <p className="text-white/90 font-medium">Owner: Haji Nadeem</p>
          <p className="text-white/70 text-sm">Expert in Premium Furniture Solutions</p>
        </div>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <Button 
            onClick={handleCall}
            size="lg"
            className="bg-white/20 hover:bg-white/30 text-white border border-white/30 hover:border-white/50 backdrop-blur-sm transition-smooth shadow-glow"
          >
            <Phone className="w-5 h-5 mr-2" />
            Call Now: +91 93263 63603
          </Button>
          <Button 
            onClick={handleWhatsApp}
            size="lg"
            className="bg-secondary hover:bg-secondary-glow text-secondary-foreground shadow-glow transition-smooth"
          >
            <MessageCircle className="w-5 h-5 mr-2" />
            WhatsApp Us
          </Button>
        </div>

        {/* Business Hours */}
        <div className="mt-12 text-white/60 text-sm">
          <p className="font-medium mb-2">Business Hours</p>
          <div className="space-y-1">
            <p>Mon - Thu: 10:00 AM - 9:00 PM</p>
            <p>Friday: Closed</p>
            <p>Sat - Sun: 10:00 AM - 9:00 PM</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;