import { useEffect, useState } from "react";

const LoadingScreen = () => {
  const [progress, setProgress] = useState(0);
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    const progressInterval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(progressInterval);
          setTimeout(() => setIsVisible(false), 500);
          return 100;
        }
        return prev + Math.random() * 15;
      });
    }, 100);

    return () => clearInterval(progressInterval);
  }, []);

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center hero-gradient">
      <div className="text-center">
        {/* Logo Animation */}
        <div className="relative mb-8">
          <div className="w-24 h-24 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center mx-auto logo-shine">
            <span className="text-5xl font-bold text-white">H</span>
          </div>
          <div className="absolute -inset-4 rounded-full border-2 border-white/30 animate-pulse" />
        </div>

        {/* Brand Name */}
        <h1 className="text-4xl md:text-5xl font-bold text-white mb-2">
          H Concept Furniture
        </h1>
        <p className="text-white/80 text-lg mb-8">
          Premium Quality • Expert Craftsmanship
        </p>

        {/* Progress Bar */}
        <div className="max-w-xs mx-auto">
          <div className="w-full bg-white/20 rounded-full h-2 mb-4 backdrop-blur-sm">
            <div 
              className="secondary-gradient h-2 rounded-full transition-all duration-300 ease-out"
              style={{ width: `${progress}%` }}
            />
          </div>
          <p className="text-white/60 text-sm">
            Loading... {Math.round(progress)}%
          </p>
        </div>
      </div>
    </div>
  );
};

export default LoadingScreen;