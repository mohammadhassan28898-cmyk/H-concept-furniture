import { Card, CardContent } from "@/components/ui/card";
import { Quote } from "lucide-react";

interface FurnitureQuote {
  text: string;
  author: string;
  category: string;
}

const quotes: FurnitureQuote[] = [
  {
    text: "Your home should tell the story of who you are, and be a collection of what you love brought together under one roof.",
    author: "Nate Berkus",
    category: "Interior Design"
  },
  {
    text: "Furniture is meant to be used and enjoyed, not just admired from afar.",
    author: "Jonathan Adler",
    category: "Design Philosophy"
  },
  {
    text: "Good furniture is a platform for life. It should be functional, comfortable, and beautiful.",
    author: "Marcel Breuer",
    category: "Functionality"
  },
  {
    text: "The details are not the details. They make the design.",
    author: "Charles Eames",
    category: "Craftsmanship"
  },
  {
    text: "A house is not a home unless it contains food and fire for the mind as well as the body.",
    author: "Benjamin Franklin",
    category: "Home & Living"
  },
  {
    text: "Design is not just what it looks like and feels like. Design is how it works.",
    author: "Steve Jobs",
    category: "Design Innovation"
  }
];

const QuotesSection = () => {
  return (
    <section className="py-20 bg-gradient-to-b from-background to-muted/20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 primary-gradient bg-clip-text text-transparent">
            Wisdom in Design
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Timeless quotes that inspire our approach to creating beautiful, functional furniture
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {quotes.map((quote, index) => (
            <Card key={index} className="relative overflow-hidden shadow-card hover:shadow-elegant transition-smooth group bg-card/50 backdrop-blur-sm">
              <CardContent className="p-8">
                <div className="absolute top-4 left-4 opacity-20">
                  <Quote className="w-12 h-12 text-primary" />
                </div>
                
                <div className="relative z-10">
                  <blockquote className="text-lg leading-relaxed mb-6 text-foreground/90 font-medium">
                    "{quote.text}"
                  </blockquote>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-semibold text-foreground">{quote.author}</p>
                      <p className="text-sm text-muted-foreground">{quote.category}</p>
                    </div>
                    <div className="w-12 h-0.5 bg-gradient-to-r from-primary to-secondary rounded-full"></div>
                  </div>
                </div>

                {/* Hover Effect */}
                <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-secondary/5 opacity-0 group-hover:opacity-100 transition-smooth"></div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Featured Quote */}
        <div className="mt-20">
          <Card className="max-w-4xl mx-auto shadow-elegant bg-gradient-to-br from-primary/5 via-card/80 to-secondary/5 backdrop-blur-sm">
            <CardContent className="p-12 text-center">
              <Quote className="w-16 h-16 text-secondary mx-auto mb-8" />
              <blockquote className="text-2xl md:text-3xl font-bold leading-relaxed mb-8 primary-gradient bg-clip-text text-transparent">
                "At H Concept Furniture, we believe that great furniture doesn't just fill a space – it transforms it into a sanctuary of comfort, style, and personal expression."
              </blockquote>
              <div className="flex items-center justify-center space-x-4">
                <div className="w-16 h-0.5 bg-gradient-to-r from-transparent to-primary rounded-full"></div>
                <p className="font-semibold text-foreground">Haji Nadeem</p>
                <div className="w-16 h-0.5 bg-gradient-to-l from-transparent to-secondary rounded-full"></div>
              </div>
              <p className="text-muted-foreground mt-2">Founder, H Concept Furniture</p>
            </CardContent>
          </Card>
        </div>

        {/* Call to Action */}
        <div className="text-center mt-16">
          <p className="text-muted-foreground mb-4">
            Let us help you create spaces that inspire and furniture that tells your story.
          </p>
        </div>
      </div>
    </section>
  );
};

export default QuotesSection;