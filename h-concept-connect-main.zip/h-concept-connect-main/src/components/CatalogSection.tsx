import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, FileText, Eye } from "lucide-react";
import { toast } from "sonner";
import catalogSofasPreview from "@/assets/catalog-sofas-preview.jpg";
import catalogDiningPreview from "@/assets/catalog-dining-preview.jpg";
import catalogBedroomPreview from "@/assets/catalog-bedroom-preview.jpg";
import catalogOfficePreview from "@/assets/catalog-office-preview.jpg";
import catalogStoragePreview from "@/assets/catalog-storage-preview.jpg";
import catalogChairsPreview from "@/assets/catalog-chairs-preview.jpg";

interface Catalog {
  id: string;
  name: string;
  description: string;
  pages: number;
  category: string;
  downloadUrl: string;
  previewImages: string[];
}

const catalogs: Catalog[] = [
  {
    id: "premium-sofas-catalog",
    name: "Premium Sofas Collection",
    description: "Explore our luxurious sofa collection featuring modern designs, premium fabrics, and exceptional comfort.",
    pages: 24,
    category: "Living Room",
    downloadUrl: "/catalogs/premium-sofas-catalog.pdf",
    previewImages: [catalogSofasPreview, catalogSofasPreview, catalogSofasPreview]
  },
  {
    id: "dining-sets-catalog",
    name: "Elegant Dining Sets",
    description: "Discover dining furniture that brings families together with style and sophistication.",
    pages: 18,
    category: "Dining Room",
    downloadUrl: "/catalogs/dining-sets-catalog.pdf",
    previewImages: [catalogDiningPreview, catalogDiningPreview, catalogDiningPreview]
  },
  {
    id: "bedroom-catalog",
    name: "Bedroom Furniture Collection",
    description: "Create your perfect sanctuary with our complete bedroom furniture solutions.",
    pages: 32,
    category: "Bedroom",
    downloadUrl: "/catalogs/bedroom-furniture-catalog.pdf",
    previewImages: [catalogBedroomPreview, catalogBedroomPreview, catalogBedroomPreview]
  },
  {
    id: "office-catalog",
    name: "Professional Office Furniture",
    description: "Enhance productivity with our ergonomic and stylish office furniture collection.",
    pages: 20,
    category: "Office",
    downloadUrl: "/catalogs/office-furniture-catalog.pdf",
    previewImages: [catalogOfficePreview, catalogOfficePreview, catalogOfficePreview]
  },
  {
    id: "storage-catalog",
    name: "Smart Storage Solutions",
    description: "Maximize your space with our innovative and beautiful storage furniture.",
    pages: 16,
    category: "Storage",
    downloadUrl: "/catalogs/storage-solutions-catalog.pdf",
    previewImages: [catalogStoragePreview, catalogStoragePreview, catalogStoragePreview]
  },
  {
    id: "chairs-catalog",
    name: "Designer Chairs Collection",
    description: "Statement pieces that combine artistic design with superior comfort.",
    pages: 14,
    category: "Chairs",
    downloadUrl: "/catalogs/designer-chairs-catalog.pdf",
    previewImages: [catalogChairsPreview, catalogChairsPreview, catalogChairsPreview]
  }
];

const CatalogSection = () => {
  const handleDownload = (catalog: Catalog) => {
    // For now, we'll show a toast. In production, this would trigger actual PDF download
    toast.success(`${catalog.name} catalog will be ready for download shortly!`);
    
    // Simulate PDF preparation
    setTimeout(() => {
      toast.info("📧 Catalog has been sent to your WhatsApp! Check your messages.");
      
      // Send catalog via WhatsApp
      const message = `Hi! I'd like to download the ${catalog.name} catalog (${catalog.pages} pages). Please send me the PDF.`;
      window.open(`https://wa.me/919326363603?text=${encodeURIComponent(message)}`, '_blank');
    }, 2000);
  };

  const handlePreview = (catalog: Catalog) => {
    toast.info("Preview feature coming soon! Contact us for a full catalog.");
  };

  return (
    <section id="catalogs" className="py-20 bg-gradient-to-br from-background via-muted/30 to-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 primary-gradient bg-clip-text text-transparent">
            Furniture Catalogs
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Browse our comprehensive furniture catalogs featuring detailed specifications, dimensions, and stunning photography
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {catalogs.map((catalog) => (
            <Card key={catalog.id} className="overflow-hidden shadow-card hover:shadow-elegant transition-smooth group bg-card/50 backdrop-blur-sm">
              <CardHeader className="p-0">
                <div className="relative overflow-hidden h-48">
                  <div className="grid grid-cols-3 gap-1 h-full">
                    {catalog.previewImages.map((img, index) => (
                      <div key={index} className="relative overflow-hidden">
                        <img 
                          src={img} 
                          alt={`${catalog.name} preview ${index + 1}`}
                          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                        />
                      </div>
                    ))}
                  </div>
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-smooth" />
                  <div className="absolute bottom-4 left-4 text-white opacity-0 group-hover:opacity-100 transition-smooth">
                    <p className="text-sm font-medium">{catalog.pages} Pages</p>
                    <p className="text-xs">{catalog.category}</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                <h3 className="text-xl font-bold mb-2">{catalog.name}</h3>
                <p className="text-muted-foreground mb-4 text-sm">{catalog.description}</p>
                
                <div className="flex items-center justify-between mb-4">
                  <span className="text-sm text-muted-foreground">
                    📖 {catalog.pages} pages
                  </span>
                  <span className="text-xs px-2 py-1 bg-primary/10 text-primary rounded-full">
                    {catalog.category}
                  </span>
                </div>

                <div className="flex gap-2">
                  <Button 
                    onClick={() => handleDownload(catalog)}
                    className="flex-1 secondary-gradient hover:opacity-90 transition-smooth"
                    size="sm"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Download PDF
                  </Button>
                  <Button 
                    onClick={() => handlePreview(catalog)}
                    variant="outline"
                    size="sm"
                    className="border-primary text-primary hover:bg-primary hover:text-primary-foreground"
                  >
                    <Eye className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <div className="bg-card/50 backdrop-blur-sm rounded-2xl p-8 max-w-2xl mx-auto shadow-card">
            <h3 className="text-2xl font-bold mb-4">Need Custom Catalogs?</h3>
            <p className="text-muted-foreground mb-6">
              We can create personalized catalogs based on your specific requirements, budget, and space dimensions.
            </p>
            <Button 
              onClick={() => {
                const message = "Hi! I need a custom furniture catalog. Can you help me create one based on my requirements?";
                window.open(`https://wa.me/919326363603?text=${encodeURIComponent(message)}`, '_blank');
              }}
              className="primary-gradient hover:opacity-90 shadow-glow transition-smooth"
            >
              <FileText className="w-5 h-5 mr-2" />
              Request Custom Catalog
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CatalogSection;