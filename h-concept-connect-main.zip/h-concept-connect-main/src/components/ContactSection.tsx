import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Phone, Mail, MessageCircle, MapPin, Clock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ContactForm {
  name: string;
  phone: string;
  email: string;
  product: string;
  budget: string;
  message: string;
}

const ContactSection = () => {
  const { toast } = useToast();
  const [formData, setFormData] = useState<ContactForm>({
    name: '',
    phone: '',
    email: '',
    product: '',
    budget: '',
    message: ''
  });

  const products = [
    "Premium Sofas",
    "Dining Sets", 
    "Bedroom Furniture",
    "Office Furniture",
    "Storage Solutions",
    "Designer Chairs",
    "Custom Requirements"
  ];

  const budgetRanges = [
    "Under ₹20,000",
    "₹20,000 - ₹50,000",
    "₹50,000 - ₹1,00,000",
    "₹1,00,000 - ₹2,00,000",
    "Above ₹2,00,000"
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.phone) {
      toast({
        title: "Please fill required fields",
        description: "Name and phone number are required.",
        variant: "destructive"
      });
      return;
    }

    // Create WhatsApp message
    const message = `
*New Inquiry from H Concept Furniture Website*

*Customer Details:*
Name: ${formData.name}
Phone: ${formData.phone}
Email: ${formData.email || 'Not provided'}

*Product Interest:* ${formData.product || 'Not specified'}
*Budget Range:* ${formData.budget || 'Not specified'}

*Message:*
${formData.message || 'No additional message'}

Please contact this customer at the earliest.
    `.trim();

    window.open(`https://wa.me/919326363603?text=${encodeURIComponent(message)}`, '_blank');
    
    toast({
      title: "Inquiry Sent!",
      description: "Your message has been sent via WhatsApp. We'll contact you soon!",
    });

    // Reset form
    setFormData({
      name: '', phone: '', email: '', product: '', budget: '', message: ''
    });
  };

  const handleCall = () => {
    window.open('tel:+919326363603', '_self');
  };

  const handleWhatsApp = () => {
    const message = "Hello! I'd like to inquire about your furniture collection.";
    window.open(`https://wa.me/919326363603?text=${encodeURIComponent(message)}`, '_blank');
  };

  const handleEmailClick = () => {
    window.open('mailto:hconceptfurnitures07@gmail.com', '_self');
  };

  return (
    <section id="contact" className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 primary-gradient bg-clip-text text-transparent">
            Get In Touch
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Ready to transform your space? Contact us for personalized furniture solutions and expert guidance.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Information */}
          <div className="space-y-8">
            <Card className="shadow-card">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Phone className="w-6 h-6 text-secondary mr-3" />
                  Direct Contact
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Haji Nadeem (Owner)</p>
                    <p className="text-2xl font-bold text-secondary">+91 93263 63603</p>
                  </div>
                  <Button onClick={handleCall} className="secondary-gradient hover:opacity-90">
                    <Phone className="w-4 h-4 mr-2" />
                    Call Now
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-card">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <MessageCircle className="w-6 h-6 text-secondary mr-3" />
                  WhatsApp & Email
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">WhatsApp</p>
                    <p className="text-muted-foreground">Instant messaging & quotes</p>
                  </div>
                  <Button onClick={handleWhatsApp} variant="outline" className="border-secondary text-secondary hover:bg-secondary hover:text-secondary-foreground">
                    <MessageCircle className="w-4 h-4 mr-2" />
                    WhatsApp
                  </Button>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Email</p>
                    <p className="text-sm text-muted-foreground">hconceptfurnitures07@gmail.com</p>
                  </div>
                  <Button onClick={handleEmailClick} variant="outline">
                    <Mail className="w-4 h-4 mr-2" />
                    Email
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-card">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Clock className="w-6 h-6 text-secondary mr-3" />
                  Business Hours
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Monday - Thursday</span>
                    <span className="font-medium">10:00 AM - 9:00 PM</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Friday</span>
                    <span className="text-red-500 font-medium">Closed</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Saturday - Sunday</span>
                    <span className="font-medium">10:00 AM - 9:00 PM</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Contact Form */}
          <Card className="shadow-card">
            <CardHeader>
              <CardTitle>Send Us Your Requirements</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Name *</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value})}
                      placeholder="Your full name"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone *</Label>
                    <Input
                      id="phone"
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => setFormData({...formData, phone: e.target.value})}
                      placeholder="+91 XXXXX XXXXX"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                    placeholder="your.email@example.com"
                  />
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Product Interest</Label>
                    <Select onValueChange={(value) => setFormData({...formData, product: value})}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select product category" />
                      </SelectTrigger>
                      <SelectContent>
                        {products.map((product) => (
                          <SelectItem key={product} value={product}>
                            {product}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Budget Range</Label>
                    <Select onValueChange={(value) => setFormData({...formData, budget: value})}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select budget range" />
                      </SelectTrigger>
                      <SelectContent>
                        {budgetRanges.map((range) => (
                          <SelectItem key={range} value={range}>
                            {range}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="message">Additional Requirements</Label>
                  <Textarea
                    id="message"
                    value={formData.message}
                    onChange={(e) => setFormData({...formData, message: e.target.value})}
                    placeholder="Tell us about your specific requirements, room dimensions, color preferences, or any other details..."
                    rows={4}
                  />
                </div>

                <Button type="submit" className="w-full secondary-gradient hover:opacity-90 shadow-glow">
                  <MessageCircle className="w-5 h-5 mr-2" />
                  Send Inquiry via WhatsApp
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;