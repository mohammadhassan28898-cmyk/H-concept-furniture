import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Phone, Mail, MessageCircle, Clock, MapPin, Heart } from "lucide-react";

const Footer = () => {
  const handleCall = () => {
    window.open('tel:+919326363603', '_self');
  };

  const handleWhatsApp = () => {
    const message = "Hello! I'm interested in H Concept Furniture products.";
    window.open(`https://wa.me/919326363603?text=${encodeURIComponent(message)}`, '_blank');
  };

  const handleEmailClick = () => {
    window.open('mailto:hconceptfurnitures07@gmail.com', '_self');
  };

  const services = [
    "Premium Sofas & Seating",
    "Dining Room Furniture",
    "Bedroom Sets & Mattresses",
    "Office & Commercial Furniture",
    "Custom Storage Solutions",
    "Designer Chairs & Decor",
    "Interior Design Consultation",
    "Furniture Repair & Maintenance"
  ];

  return (
    <footer className="bg-primary text-primary-foreground">
      <div className="container mx-auto px-4 py-16">
        <div className="grid lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="lg:col-span-1 space-y-6">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-12 h-12 rounded-full secondary-gradient flex items-center justify-center logo-shine">
                  <span className="text-secondary-foreground font-bold text-xl">H</span>
                </div>
                <div>
                  <h3 className="text-2xl font-bold">H Concept</h3>
                  <p className="text-primary-foreground/80">Furniture</p>
                </div>
              </div>
              <p className="text-primary-foreground/80 leading-relaxed">
                Transform your space with premium quality furniture. We specialize in modern and classic designs that bring comfort and style to your home and office.
              </p>
            </div>

            <Card className="bg-white/10 border-white/20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                    <span className="text-xs font-bold">HN</span>
                  </div>
                  <div>
                    <p className="font-medium">Haji Nadeem</p>
                    <p className="text-xs text-primary-foreground/70">Founder & Owner</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Services */}
          <div className="lg:col-span-1">
            <h4 className="text-xl font-bold mb-6">Our Services</h4>
            <ul className="space-y-3">
              {services.map((service, index) => (
                <li key={index} className="text-primary-foreground/80 hover:text-primary-foreground transition-colors text-sm">
                  {service}
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div className="lg:col-span-1">
            <h4 className="text-xl font-bold mb-6">Contact Information</h4>
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <Phone className="w-5 h-5 text-secondary mt-0.5" />
                <div>
                  <p className="font-medium">Call Us</p>
                  <p className="text-primary-foreground/80 text-sm">+91 93263 63603</p>
                  <p className="text-xs text-primary-foreground/60">Available during business hours</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3">
                <Mail className="w-5 h-5 text-secondary mt-0.5" />
                <div>
                  <p className="font-medium">Email Us</p>
                  <p className="text-primary-foreground/80 text-sm break-all">hconceptfurnitures07@gmail.com</p>
                </div>
              </div>

              <div className="flex items-start space-x-3">
                <MessageCircle className="w-5 h-5 text-secondary mt-0.5" />
                <div>
                  <p className="font-medium">WhatsApp</p>
                  <p className="text-primary-foreground/80 text-sm">Quick quotes & support</p>
                </div>
              </div>
            </div>
          </div>

          {/* Business Hours & Actions */}
          <div className="lg:col-span-1">
            <h4 className="text-xl font-bold mb-6">Business Hours</h4>
            <div className="space-y-3 mb-6">
              <div className="flex justify-between text-sm">
                <span>Monday - Thursday</span>
                <span className="text-secondary font-medium">10AM - 9PM</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Friday</span>
                <span className="text-red-300 font-medium">Closed</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Saturday - Sunday</span>
                <span className="text-secondary font-medium">10AM - 9PM</span>
              </div>
            </div>

            <div className="space-y-3">
              <Button 
                onClick={handleCall}
                className="w-full bg-white/20 hover:bg-white/30 text-primary-foreground border border-white/30"
              >
                <Phone className="w-4 h-4 mr-2" />
                Call Now
              </Button>
              <Button 
                onClick={handleWhatsApp}
                className="w-full secondary-gradient hover:opacity-90"
              >
                <MessageCircle className="w-4 h-4 mr-2" />
                WhatsApp Us
              </Button>
              <Button 
                onClick={handleEmailClick}
                variant="outline"
                className="w-full border-white/30 text-primary-foreground hover:bg-white/10"
              >
                <Mail className="w-4 h-4 mr-2" />
                Send Email
              </Button>
            </div>
          </div>
        </div>

        <Separator className="my-8 bg-white/20" />

        <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          <div className="text-center md:text-left">
            <p className="text-primary-foreground/80 text-sm">
              © 2024 H Concept Furniture. All rights reserved.
            </p>
            <p className="text-primary-foreground/60 text-xs mt-1">
              Crafted with excellence for your perfect space.
            </p>
          </div>
          
          <div className="flex items-center space-x-2 text-sm text-primary-foreground/60">
            <span>Made with</span>
            <Heart className="w-4 h-4 text-red-400 fill-current" />
            <span>for furniture lovers</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;