import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Phone, MessageCircle, ArrowUp } from "lucide-react";

const FloatingActions = () => {
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 400);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleCall = () => {
    window.open('tel:+919326363603', '_self');
  };

  const handleWhatsApp = () => {
    const message = "Hello! I'm interested in H Concept Furniture. Can you help me?";
    window.open(`https://wa.me/919326363603?text=${encodeURIComponent(message)}`, '_blank');
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="fixed bottom-6 right-6 z-40 flex flex-col space-y-3">
      {/* WhatsApp Button */}
      <Button
        onClick={handleWhatsApp}
        size="lg"
        className="w-14 h-14 rounded-full shadow-glow secondary-gradient hover:opacity-90 transition-smooth group"
        title="WhatsApp Us"
      >
        <MessageCircle className="w-6 h-6 group-hover:scale-110 transition-transform" />
      </Button>

      {/* Call Button */}
      <Button
        onClick={handleCall}
        size="lg"
        variant="outline"
        className="w-14 h-14 rounded-full shadow-elegant border-primary text-primary hover:bg-primary hover:text-primary-foreground transition-smooth group"
        title="Call Now"
      >
        <Phone className="w-6 h-6 group-hover:scale-110 transition-transform" />
      </Button>

      {/* Scroll to Top Button */}
      {showScrollTop && (
        <Button
          onClick={scrollToTop}
          size="lg"
          variant="outline"
          className="w-14 h-14 rounded-full shadow-card hover:shadow-elegant transition-smooth group opacity-70 hover:opacity-100"
          title="Back to Top"
        >
          <ArrowUp className="w-6 h-6 group-hover:scale-110 transition-transform" />
        </Button>
      )}
    </div>
  );
};

export default FloatingActions;