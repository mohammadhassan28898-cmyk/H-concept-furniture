import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Star, Award, Users, Clock } from "lucide-react";

const BusinessStory = () => {
  const achievements = [
    { icon: Users, label: "5000+", description: "Happy Customers" },
    { icon: Award, label: "15+", description: "Years Experience" },
    { icon: Star, label: "4.9/5", description: "Customer Rating" },
    { icon: Clock, label: "24/7", description: "Customer Support" }
  ];

  return (
    <section className="py-20 bg-gradient-to-br from-muted/20 via-background to-muted/20">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          {/* Main Story */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-20">
            <div>
              <Badge variant="secondary" className="mb-4">Our Story</Badge>
              <h2 className="text-4xl md:text-5xl font-bold mb-6 primary-gradient bg-clip-text text-transparent">
                Crafting Dreams into Reality Since 2009
              </h2>
              <div className="space-y-4 text-muted-foreground text-lg leading-relaxed">
                <p>
                  <strong className="text-foreground">H Concept Furniture</strong> began as a vision to transform ordinary spaces into extraordinary experiences. Founded by <strong className="text-foreground">Haji Nadeem</strong>, our journey started with a simple belief: every piece of furniture should tell a story and every home should reflect the personality of its inhabitants.
                </p>
                <p>
                  With over <strong className="text-secondary">15 years of expertise</strong> in the furniture industry, we have evolved from a small workshop to one of the most trusted names in premium furniture manufacturing and retail. Our commitment to quality, innovation, and customer satisfaction has earned us the loyalty of over <strong className="text-secondary">5,000 satisfied customers</strong> across the region.
                </p>
                <p>
                  At H Concept Furniture, we don't just sell furniture – we create lifestyle solutions. Our team of skilled craftsmen and designers work tirelessly to bring you pieces that combine <strong className="text-foreground">timeless elegance</strong> with <strong className="text-foreground">contemporary functionality</strong>. From luxury sofas and dining sets to ergonomic office furniture and smart storage solutions, every piece is crafted with precision and passion.
                </p>
                <p>
                  What sets us apart is our <strong className="text-secondary">personalized approach</strong>. We understand that furniture is not just about filling spaces – it's about creating memories, fostering comfort, and expressing individuality. That's why we offer customization options, ensuring that every piece perfectly fits your space, style, and story.
                </p>
              </div>
            </div>
            
            <div className="relative">
              <div className="bg-gradient-to-br from-primary/20 to-secondary/20 rounded-3xl p-8 backdrop-blur-sm">
                <div className="bg-card/80 backdrop-blur-sm rounded-2xl p-6 shadow-elegant">
                  <h3 className="text-2xl font-bold mb-4 text-center">Why Choose H Concept?</h3>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-3 h-3 bg-secondary rounded-full"></div>
                      <span className="text-muted-foreground">Premium Quality Materials & Craftsmanship</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-3 h-3 bg-secondary rounded-full"></div>
                      <span className="text-muted-foreground">Customization Options Available</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-3 h-3 bg-secondary rounded-full"></div>
                      <span className="text-muted-foreground">Competitive Pricing & Flexible Payment</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-3 h-3 bg-secondary rounded-full"></div>
                      <span className="text-muted-foreground">Free Delivery & Installation Service</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-3 h-3 bg-secondary rounded-full"></div>
                      <span className="text-muted-foreground">Comprehensive Warranty & After-Sales Support</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-3 h-3 bg-secondary rounded-full"></div>
                      <span className="text-muted-foreground">Eco-Friendly & Sustainable Practices</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Achievements */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {achievements.map((achievement, index) => {
              const IconComponent = achievement.icon;
              return (
                <Card key={index} className="text-center p-6 shadow-card hover:shadow-elegant transition-smooth bg-card/50 backdrop-blur-sm">
                  <CardContent className="p-0">
                    <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
                      <IconComponent className="w-8 h-8 text-primary" />
                    </div>
                    <h3 className="text-2xl md:text-3xl font-bold mb-2 secondary-gradient bg-clip-text text-transparent">
                      {achievement.label}
                    </h3>
                    <p className="text-muted-foreground text-sm">{achievement.description}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Mission Statement */}
          <div className="mt-20 text-center">
            <div className="bg-gradient-to-r from-primary/5 via-secondary/5 to-primary/5 rounded-3xl p-12">
              <h3 className="text-3xl font-bold mb-6">Our Mission</h3>
              <p className="text-xl text-muted-foreground max-w-4xl mx-auto leading-relaxed">
                "To transform living and working spaces with thoughtfully designed, high-quality furniture that enhances comfort, functionality, and aesthetic appeal. We are committed to delivering exceptional value through innovative design, superior craftsmanship, and unparalleled customer service."
              </p>
              <div className="mt-8">
                <p className="text-lg font-medium">- Haji Nadeem, Founder & CEO</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default BusinessStory;