import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Phone, MessageCircle, IndianRupee } from "lucide-react";
import premiumSofasImg from "@/assets/premium-sofas.jpg";
import diningSetsImg from "@/assets/dining-sets.jpg";
import bedroomFurnitureImg from "@/assets/bedroom-furniture.jpg";
import officeFurnitureImg from "@/assets/office-furniture.jpg";
import storageSolutionsImg from "@/assets/storage-solutions.jpg";
import designerChairsImg from "@/assets/designer-chairs.jpg";

interface Product {
  id: string;
  name: string;
  price: number;
  image: string;
  description: string;
}

const products: Product[] = [
  {
    id: "premium-sofas",
    name: "Premium Sofas",
    price: 35000,
    image: premiumSofasImg,
    description: "Luxurious and comfortable sofas crafted with premium materials"
  },
  {
    id: "dining-sets",
    name: "Dining Sets",
    price: 35000,
    image: diningSetsImg,
    description: "Elegant dining sets perfect for family gatherings and entertaining"
  },
  {
    id: "bedroom-furniture",
    name: "Bedroom Furniture",
    price: 55000,
    image: bedroomFurnitureImg,
    description: "Complete bedroom solutions for a restful and stylish sanctuary"
  },
  {
    id: "office-furniture",
    name: "Office Furniture",
    price: 25000,
    image: officeFurnitureImg,
    description: "Professional office furniture for productive work environments"
  },
  {
    id: "storage-solutions",
    name: "Storage Solutions",
    price: 18000,
    image: storageSolutionsImg,
    description: "Smart storage solutions to keep your space organized and clutter-free"
  },
  {
    id: "designer-chairs",
    name: "Designer Chairs",
    price: 12000,
    image: designerChairsImg,
    description: "Artistic and comfortable chairs that make a statement"
  }
];

const ProductsSection = () => {
  const handleProductInquiry = (product: Product) => {
    const message = `Hi! I'm interested in ${product.name} (₹${product.price.toLocaleString()}). Can you provide more details?`;
    window.open(`https://wa.me/919326363603?text=${encodeURIComponent(message)}`, '_blank');
  };

  const handleCall = () => {
    window.open('tel:+919326363603', '_self');
  };

  return (
    <section id="products" className="py-20 bg-muted/50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 primary-gradient bg-clip-text text-transparent">
            Our Premium Collection
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Discover our carefully curated selection of premium furniture designed to transform your living spaces
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {products.map((product) => (
            <Card key={product.id} className="overflow-hidden shadow-card hover:shadow-elegant transition-smooth group">
              <CardHeader className="p-0">
                <div className="relative overflow-hidden h-64">
                  <img 
                    src={product.image} 
                    alt={product.name}
                    className="w-full h-full object-cover transition-smooth group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-smooth" />
                </div>
              </CardHeader>
              <CardContent className="p-6">
                <h3 className="text-2xl font-bold mb-2">{product.name}</h3>
                <p className="text-muted-foreground mb-4">{product.description}</p>
                
                <div className="flex items-center mb-6">
                  <IndianRupee className="w-5 h-5 text-secondary mr-1" />
                  <span className="text-2xl font-bold text-secondary">
                    {product.price.toLocaleString()}
                  </span>
                  <span className="text-muted-foreground ml-1">*</span>
                </div>

                <div className="flex flex-col sm:flex-row gap-3">
                  <Button 
                    onClick={() => handleProductInquiry(product)}
                    className="flex-1 secondary-gradient hover:opacity-90 transition-smooth"
                  >
                    <MessageCircle className="w-4 h-4 mr-2" />
                    WhatsApp Inquiry
                  </Button>
                  <Button 
                    onClick={handleCall}
                    variant="outline"
                    className="border-primary text-primary hover:bg-primary hover:text-primary-foreground transition-smooth"
                  >
                    <Phone className="w-4 h-4 mr-2" />
                    Call
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <p className="text-sm text-muted-foreground mb-6">
            * Prices may vary based on customization, materials, and dimensions. Contact us for exact quotes.
          </p>
          <Button 
            onClick={handleCall}
            size="lg"
            className="primary-gradient hover:opacity-90 shadow-glow transition-smooth"
          >
            <Phone className="w-5 h-5 mr-2" />
            Get Custom Quote: +91 93263 63603
          </Button>
        </div>
      </div>
    </section>
  );
};

export default ProductsSection;