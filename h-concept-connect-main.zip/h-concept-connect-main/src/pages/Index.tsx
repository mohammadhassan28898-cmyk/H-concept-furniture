import { useState, useEffect } from "react";
import LoadingScreen from "@/components/LoadingScreen";
import Navigation from "@/components/Navigation";
import HeroSection from "@/components/HeroSection";
import BusinessStory from "@/components/BusinessStory";
import ProductsSection from "@/components/ProductsSection";
import CatalogSection from "@/components/CatalogSection";
import QuotesSection from "@/components/QuotesSection";
import ReviewSection from "@/components/ReviewSection";
import AboutSection from "@/components/AboutSection";
import ContactSection from "@/components/ContactSection";
import Footer from "@/components/Footer";
import FloatingActions from "@/components/FloatingActions";

const Index = () => {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate loading time
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 2500);

    return () => clearTimeout(timer);
  }, []);

  if (isLoading) {
    return <LoadingScreen />;
  }

  return (
    <div className="min-h-screen">
      <Navigation />
      <HeroSection />
      <BusinessStory />
      <ProductsSection />
      <CatalogSection />
      <QuotesSection />
      <ReviewSection />
      <AboutSection />
      <ContactSection />
      <Footer />
      <FloatingActions />
    </div>
  );
};

export default Index;
